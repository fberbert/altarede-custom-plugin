define('altarede-custom-plugin:views/record/edit', 'views/record/edit', function (Dep) {

    return Dep.extend({

        template: 'altarede-custom-plugin:record/edit',

    });
});
