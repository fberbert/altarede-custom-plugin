define('altarede-custom-plugin:views/site/navbar', 'views/site/navbar', function (Dep) {

    return Dep.extend({

        template: 'altarede-custom-plugin:site/navbar',

    });
});
