define('altarede-custom-plugin:views/record/detail', 'views/record/detail', function (Dep) {

    return Dep.extend({

        template: 'altarede-custom-plugin:record/detail',

    });
});
